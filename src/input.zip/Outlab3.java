
package outlab3;
    import java.io.File;
import java.io.IOException;
    import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Benjamin Haedt
 */
public class Outlab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Outlab3 test = new Outlab3();
    }

 Outlab3(){
        Scanner console = new Scanner(System.in);
        Scanner inFile;
        int x;
        int y = 1;
        PoliticsList list = new PoliticsList();
        System.out.println("Enter 1 to play with the double circular linked list, or 2 to work with file input and output");
        y = console.nextInt();
        switch (y){
            case 1:
                 while (y != 0){
                System.out.println("enter 1 to create node, 2 to print list, 3 to get data from last element, 4 to get size, 8 to get data from first element, 0 to exit");
                System.out.println("enter 5 to create a linked list with x number of nodes, 6 will count clockwise and remove the node, 7 will count counter clockwise and remove the node");
                y = console.nextInt();
            if (y == 1){
                System.out.println("create a new node with (int) value");
                x = console.nextInt();
                Node node = new Node(x);
                list.add(node);
            }
            if (y == 2){
                list.print();
            }
            if (y ==3){
                System.out.println(list.last());
            }
            if (y ==4){
                System.out.println(list.size());
            }
            if (y ==5){
                System.out.println("enter how many nodes to be created");
                x = console.nextInt();
                for (int i = 0; i < x; i++){
                 Node node = new Node(i+1);
                list.add(node);
                }
            }
            if (y == 6){
                System.out.println("enter what node will start from the first candidate and move clockwise around then delete that node");
                x = console.nextInt();
//                if (x > 1){
//                    x--;
//                }
//                else{
//                    x++;
//                }
                list.kSelector(x);
            }    
        
                 if (y == 7){
                System.out.println("enter what node will start from the first candidate and move counter clockwise around then delete that node");
                x = console.nextInt();
//                if (x > 1){
//                    x--;
//                }
                list.mSelector(x);
                 }
            if (y ==3){
                System.out.println(list.first());
            }
        }
            case 2:
            while (y != 0){
            System.out.println("Enter 1 to enter a file to read from or 0 to quit"); 
            y = console.nextInt();
            if (y == 1){
            //Scanner question= new Scanner(System.in);
            Scanner fin;
            //String input = question.next();
            try{
            new FileOpenReadWrite();
                }catch(Exception e)
                {
            System.out.println("Usage: Need file input name");
            System.err.println(e);
                }
            }
            if (y == 2){
                break;
            }
            
            
//            String myPolitics;
//            switch (y) {
//                case 1:{
//                    System.out.println("enter the file to read from");
//                    String fileToOpen = question.nextLine();
//                    File file = new File(fileToOpen);
//                    
//                try {
//                    Scanner sc = new Scanner(file);
//                    while (sc.hasNextLine()){
//                       myPolitics = sc.nextLine();
//                    }
//                    //System.out.println(myPoltics);
//                } catch (FileNotFoundException ex) {
//                    Logger.getLogger(Outlab3.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                }
//            }
            break;
        }
        }
        
 }
    public class FileOpenReadWrite {

    Scanner fin;
    FileOut fout;
    
    FileOpenReadWrite(){
        //System.out.println(fileName);
        File file = new File("C:\\Users\\Togusa\\Documents\\NetBeansProjects\\Outlab3\\input.txt");
        
        
        try{
            fin = new Scanner(new File("C:\\Users\\Togusa\\Documents\\NetBeansProjects\\Outlab3\\input.txt"));
        }catch(IOException e)
        {
            System.err.println(e);
        }
                System.out.println("Here22");
        fout = new FileOut("output.txt");
        int count=0;
        while(fin.hasNext()){
            int num = fin.nextInt();
			
			
//			if(count==0) N=num; count++
//			else ==1 j=num; count++
//			else ==2 k=num; count=0
//			
        
            System.out.println(num);
            if (num !=0){
                fout.write(num + " ");
            }
            else{
                break;
            }
            }
    }
    }
}
                
            
//            
//            while(inFile.hasNext()){
//            int num = inFile.nextInt();
//            System.out.println(num);
//            }
//            
////            for( int i = 0; i < inFile.length(); i++){
////                System.out.println(file.charAt(i));
////            }
//                
//                    break;
//                }
//                case 0:
//                    System.exit(0);
//    }
//    
//}
      


        
