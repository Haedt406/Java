/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package outlab3;

/**
 *
 * @author Benjamin Haedt
 */
public class PoliticsList {
    
    private Node first;
    private int size = 0;
    public boolean isEmpty(){
        return size ==0;
    }
    PoliticsList(){
        first = null;
    }
    public void remove(Node temp){
        
        Node next = temp.getNext();
        Node prev = temp.getPrev();
        if (temp != first)
        {
            prev = temp.getPrev();
            next = temp.getNext();
            prev.setNext(next);
            next.setPrev(prev);
        }
        else{
            
            temp = temp.getNext();
            prev = temp.getPrev();
            first = prev;
            next = temp.getNext();
            prev.setNext(next);
            next.setPrev(prev);
            
        }
        
//        temp.setNext(null);
//        temp.setPrev(null);
        size--;
    }
    public void kSelector(int jumps){
        Node temp = first;
        if (jumps > 1){
        for (int i = 0; i < jumps; i++){
            temp = temp.getNext();
        }
        }
        
        
        System.out.println(temp.getElement());
        remove(temp);
    }
        public void mSelector(int jumps){
        Node temp = first;
        if (jumps > 1){
        for (int i = 0; i < jumps; i++){
            temp = temp.getPrev();
        }
        }
        System.out.println(temp.getElement());
        remove(temp);
    }
    public void addPolitics(Node data){
        size += 1;
       
        if (first == null){
            first = data;
            data.setNext(data);
            data.setPrev(data);
        }
        
        Node before = first.getPrev();
        Node after = first;
        
        before.setNext(data);
        after.setPrev(data);
        data.setNext(after);
        data.setPrev(before);
        
    }
    public void add(Node data){
        size += 1;
        if (first == null){
            first = data;
            data.setNext(data);
            data.setPrev(data);
        }
        
        Node before = first.getPrev();
        Node after = first;
        
        before.setNext(data);
        after.setPrev(data);
        data.setNext(after);
        data.setPrev(before);
        
    }
    public void print(){
        Node temp = first;
        if( size == 0){
            System.out.println("List is empty");
        }
        for (int i = 0; size > i; i++){
        System.out.println(temp.getElement());
        temp = temp.getNext();
        }
    }
    public int size(){
        return size;
    }
    public int last(){
        Node temp = first;
       temp = temp.getPrev();
       return temp.getElement();
    }
    public int first(){
        Node temp = first;
       return temp.getElement();
    }
}
